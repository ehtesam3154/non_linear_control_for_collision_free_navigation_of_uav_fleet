
% Opens next to editor (Without taking the size parameters):
f1=figure;
%title('Five UAV Cluster')
xlabel('X-Axis');
ylabel('Y-Axis');
zlabel('Z-Axis');
f1.Name = 'Five UAV Cluster';
f1.Position=[150,0,1000,650];
% Opens in new window:
plot3(out.positionUAV1.Data(1,:),out.positionUAV1.Data(2,:),out.positionUAV1.Data(3,:))
hold on
plot3(out.positionUAV2.Data(1,:),out.positionUAV2.Data(2,:),out.positionUAV2.Data(3,:))
hold on
plot3(out.positionUAV3.Data(1,:),out.positionUAV3.Data(2,:),out.positionUAV3.Data(3,:))
hold on
plot3(out.positionUAV4.Data(1,:),out.positionUAV4.Data(2,:),out.positionUAV4.Data(3,:))
hold on
plot3(out.positionUAV5.Data(1,:),out.positionUAV5.Data(2,:),out.positionUAV5.Data(3,:))
hold off