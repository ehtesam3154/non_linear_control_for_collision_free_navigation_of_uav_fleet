% Opens next to editor (Without taking the size parameters):
f1=figure;
%title('Five UAV Cluster')
xlabel('X-Axis');
ylabel('Y-Axis');
zlabel('Z-Axis');
f1.Name = 'UAV5';
f1.Position=[150,0,1000,650];
% Opens in new window:
plot3(out.positionUAV5.Data(1,:),out.positionUAV5.Data(2,:),out.positionUAV5.Data(3,:))